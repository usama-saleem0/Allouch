(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_views_admin_buttons_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/buttons.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/buttons.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'Buttons'
});

/***/ }),

/***/ "./resources/js/views/admin/buttons.vue":
/*!**********************************************!*\
  !*** ./resources/js/views/admin/buttons.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _buttons_vue_vue_type_template_id_e746145c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./buttons.vue?vue&type=template&id=e746145c& */ "./resources/js/views/admin/buttons.vue?vue&type=template&id=e746145c&");
/* harmony import */ var _buttons_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./buttons.vue?vue&type=script&lang=js& */ "./resources/js/views/admin/buttons.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__.default)(
  _buttons_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__.default,
  _buttons_vue_vue_type_template_id_e746145c___WEBPACK_IMPORTED_MODULE_0__.render,
  _buttons_vue_vue_type_template_id_e746145c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/admin/buttons.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/views/admin/buttons.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/views/admin/buttons.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_buttons_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./buttons.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/buttons.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_buttons_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__.default); 

/***/ }),

/***/ "./resources/js/views/admin/buttons.vue?vue&type=template&id=e746145c&":
/*!*****************************************************************************!*\
  !*** ./resources/js/views/admin/buttons.vue?vue&type=template&id=e746145c& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_buttons_vue_vue_type_template_id_e746145c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_buttons_vue_vue_type_template_id_e746145c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_buttons_vue_vue_type_template_id_e746145c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./buttons.vue?vue&type=template&id=e746145c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/buttons.vue?vue&type=template&id=e746145c&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/buttons.vue?vue&type=template&id=e746145c&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/admin/buttons.vue?vue&type=template&id=e746145c& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", [
      _c("h1", { staticClass: "h3 mb-4 text-gray-800" }, [_vm._v("Buttons")]),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-lg-6" }, [
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c("div", { staticClass: "card-header py-3" }, [
              _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                _vm._v("Circle Buttons")
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("p", [
                _vm._v(
                  "\n            Use Font Awesome Icons (included with this theme package) along\n            with the circle buttons as shown in the examples below!\n          "
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "mb-2" }, [
                _c("code", [_vm._v(".btn-circle")])
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-primary btn-circle",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fab fa-facebook-f" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-success btn-circle",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-check" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-info btn-circle",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-info-circle" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-warning btn-circle",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-exclamation-triangle" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-danger btn-circle",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-trash" })]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "mt-4 mb-2" }, [
                _c("code", [_vm._v(".btn-circle .btn-sm")])
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-primary btn-circle btn-sm",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fab fa-facebook-f" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-success btn-circle btn-sm",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-check" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-info btn-circle btn-sm",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-info-circle" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-warning btn-circle btn-sm",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-exclamation-triangle" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-danger btn-circle btn-sm",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-trash" })]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "mt-4 mb-2" }, [
                _c("code", [_vm._v(".btn-circle .btn-lg")])
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-primary btn-circle btn-lg",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fab fa-facebook-f" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-success btn-circle btn-lg",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-check" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-info btn-circle btn-lg",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-info-circle" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-warning btn-circle btn-lg",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-exclamation-triangle" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-danger btn-circle btn-lg",
                  attrs: { href: "#" }
                },
                [_c("i", { staticClass: "fas fa-trash" })]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c("div", { staticClass: "card-header py-3" }, [
              _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                _vm._v("Brand Buttons")
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("p", [
                _vm._v(
                  "\n            Google and Facebook buttons are available featuring each company's\n            respective brand color. They are used on the user login and\n            registration pages.\n          "
                )
              ]),
              _vm._v(" "),
              _c("p", [
                _vm._v(
                  "\n            You can create more custom buttons by adding a new color variable\n            in the "
                ),
                _c("code", [_vm._v("_variables.scss")]),
                _vm._v(
                  " file and then using the\n            Bootstrap button variant mixin to create a new style, as\n            demonstrated in the "
                ),
                _c("code", [_vm._v("_buttons.scss")]),
                _vm._v(" file.\n          ")
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-google btn-block",
                  attrs: { href: "#" }
                },
                [
                  _c("i", { staticClass: "fab fa-google fa-fw" }),
                  _vm._v(" .btn-google")
                ]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-facebook btn-block",
                  attrs: { href: "#" }
                },
                [
                  _c("i", { staticClass: "fab fa-facebook-f fa-fw" }),
                  _vm._v(" .btn-facebook")
                ]
              )
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-lg-6" }, [
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c("div", { staticClass: "card-header py-3" }, [
              _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                _vm._v("\n            Split Buttons with Icon\n          ")
              ])
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("p", [
                _vm._v(
                  "\n            Works with any button colors, just use the\n            "
                ),
                _c("code", [_vm._v(".btn-icon-split")]),
                _vm._v(
                  " class and the markup in the examples\n            below. The examples below also use the\n            "
                ),
                _c("code", [_vm._v(".text-white-50")]),
                _vm._v(
                  " helper class on the icons for\n            additional styling, but it is not required.\n          "
                )
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-primary btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-flag" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Primary")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-success btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-check" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Success")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-info btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-info-circle" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Info")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-warning btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-exclamation-triangle" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Warning")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-danger btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-trash" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Danger")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-secondary btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-arrow-right" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Secondary")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-light btn-icon-split",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-gray-600" }, [
                    _c("i", { staticClass: "fas fa-arrow-right" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Light")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "mb-4" }),
              _vm._v(" "),
              _c("p", [
                _vm._v("Also works with small and large button classes!")
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-primary btn-icon-split btn-sm",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-flag" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Small")
                  ])
                ]
              ),
              _vm._v(" "),
              _c("div", { staticClass: "my-2" }),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-primary btn-icon-split btn-lg",
                  attrs: { href: "#" }
                },
                [
                  _c("span", { staticClass: "icon text-white-50" }, [
                    _c("i", { staticClass: "fas fa-flag" })
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "text" }, [
                    _vm._v("Split Button Large")
                  ])
                ]
              )
            ])
          ])
        ])
      ])
    ])
  }
]
render._withStripped = true



/***/ })

}]);