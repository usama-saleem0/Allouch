<template>
<div class="main-div">
 <div class="main-box">
    <div class="logo-from">
        <img src="/images/logo.png" alt="">
    </div>
    <div class="main-form">
        
       
       
  

    

        <div class="form-col-2">
            <div class="input-box">
                <div class="input-group">
                    <label for="text">Title</label>
                    <!-- <input type="text" placeholder="Basic One" v-model="form.title"> -->
                    <select id="title" v-model="form.title">
      <option value="Basic One">Basic One</option>
      <option value="Advance One">Advance One</option>
      <option value="Premium One">Premium One</option>

      <!-- Add more options as needed -->
    </select>
                </div>
                <div class="input-group">
                    <label for="text">Price</label>
                    <input type="number" placeholder="$20" v-model="form.price">
                </div>
                <div class="input-group-1">
                    <label for="text">Description</label>
                    <textarea  type="text" placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit. In semper pharetra ligula." v-model="form.description"></textarea>
                    <!-- <input type="text " placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit. In semper pharetra ligula finibus malesuada. Nullam vitae diam viverra, vehicula ligula vitae, eleifend mi. Suspendisse tempus eros eu ligula aliquam"> -->
                </div>
               
                <div class="input-3">
                        <label for="text">Included you want</label>
                        <input class="icon-input1" type="text" placeholder="" v-model="form.Included1">
                        <input class="icon-input2" type="text" placeholder="" v-model="form.Included2">
                        <input class="icon-input3" type="text" placeholder="" v-model="form.Included3">
                        <input class="icon-input4" type="text" placeholder="" v-model="form.Included4">

                    </div>

                    <div class="col-12">
                        <label for="text" style="color:black">Time Duration</label>
                    </div>
                    
                    <div class="input-group">
                 
                    <input type="number" placeholder="Hours" v-model="form.hours">
                </div>
                <div class="input-group">
                    
                    <input type="number" placeholder="Minutes" v-model="form.minutes">
                </div>


            </div>
            <br>

            <div class="buttons" >
                        <button class="Hire" style="background-color: #f96; color: white;" @click="save">Add Package<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none" >
  <path d="M2.51279 5.45247C3.05059 5.44296 3.53656 5.41538 4.0192 5.49859C4.07008 5.50715 4.12904 5.4791 4.18278 5.46293C4.44763 5.38304 4.71344 5.37211 4.98305 5.44106C5.21748 5.50097 5.45666 5.44961 5.69394 5.46721C6.06008 5.49431 6.42432 5.39541 6.78809 5.41395C7.08433 5.42917 7.3839 5.42441 7.67824 5.47054C7.82755 5.49384 7.96877 5.50192 8.12141 5.46341C8.28736 5.42204 8.45189 5.52142 8.62402 5.52142C8.81328 5.52142 8.99968 5.56897 9.18132 5.62318C9.38484 5.68357 9.43619 5.86806 9.28784 6.01785C9.06149 6.24657 8.76573 6.3469 8.4595 6.3916C8.20605 6.42869 7.94738 6.45008 7.69203 6.4634C7.42194 6.47719 7.14995 6.57039 6.87605 6.48004C6.82898 6.46435 6.77049 6.46102 6.72294 6.47386C6.40435 6.56136 6.07292 6.50239 5.75195 6.56516C5.65305 6.58465 5.54463 6.578 5.44382 6.56231C5.30402 6.54043 5.16993 6.54424 5.03679 6.58798C4.86656 6.64409 4.69728 6.57277 4.52657 6.57609C4.35396 6.57942 4.18278 6.5856 4.0192 6.62697C3.76195 6.69259 3.50613 6.65598 3.25553 6.62935C3.02919 6.60558 2.81093 6.62555 2.58792 6.63125C2.37727 6.63696 2.15711 6.65503 1.94979 6.61842C1.71441 6.57657 1.61217 6.36164 1.52611 6.16525C1.44907 5.98932 1.55749 5.8595 1.67589 5.73302C1.8504 5.54614 2.05154 5.44628 2.3107 5.46388C2.39534 5.46958 2.48141 5.45389 2.51422 5.45199L2.51279 5.45247Z" fill="white"/>
  <path d="M9.13513 9.8451C8.83651 9.84748 8.60731 9.58072 8.65724 9.27068C8.69005 9.06574 8.76518 8.87411 8.89833 8.70768C9.00056 8.57977 9.10422 8.45091 9.18839 8.31111C9.48177 7.82181 9.80322 7.35391 10.1884 6.93166C10.2221 6.89457 10.2497 6.84654 10.2664 6.79899C10.3657 6.51416 10.565 6.2978 10.7595 6.07907C10.8779 5.94593 10.8883 5.84702 10.7533 5.7291C10.5745 5.57265 10.4347 5.39386 10.3353 5.17798C10.2649 5.02582 10.1166 4.93737 10.0082 4.81612C9.85743 4.64731 9.76043 4.44094 9.65439 4.24646C9.50745 3.97685 9.2949 3.76192 9.12229 3.5156C8.94825 3.26739 8.80227 3.00396 8.69671 2.71913C8.67294 2.65493 8.65629 2.58646 8.64964 2.51846C8.63775 2.39008 8.71573 2.31019 8.81607 2.2479C8.91069 2.18894 8.9958 2.21366 9.07949 2.27595C9.24497 2.39911 9.42043 2.5042 9.54882 2.67728C9.71287 2.89792 9.96299 3.0439 10.1052 3.28736C10.4799 3.50086 10.6601 3.88507 10.9159 4.20414C11.0662 4.39149 11.2497 4.55364 11.4261 4.71817C11.5683 4.85083 11.6843 4.99586 11.7357 5.18654C11.7656 5.29733 11.8322 5.38673 11.894 5.48136C12.0414 5.70722 12.0319 5.93737 11.8874 6.16276C11.6739 6.49562 11.497 6.85225 11.2549 7.16703C11.0039 7.49371 10.8375 7.87982 10.545 8.17844C10.3672 8.36008 10.273 8.59356 10.1632 8.81847C10.0115 9.12898 9.83222 9.4238 9.57782 9.66345C9.43755 9.79517 9.30917 9.84415 9.13656 9.84557L9.13513 9.8451Z" fill="white"/>
</svg></button>
                        
                    </div>
        </div>
    </div>
 </div>
</div>
</template>

<script>
import Vue from 'vue'
import chartBarDemo from "../../chart/demo/chart-bar-demo";
import { get , byMethod} from '../admin/components/lib/api'
export default {
    name: 'admin',

   

    data () {
            return {
                method:'POST',
                model:{},
                model:'',
                selectedImage: null,
                images: '',

                file: {},
               


                form: {},
                

               
               
              
              
              
            }
        },
        created(){
        
        // get('/getuser')
        //       .then((res) => {
                
        //          this.setData(res)

        //       })
          
        }, 

        methods:{

            openFileInput() {
      // Trigger a click on the hidden file input element
      this.$refs.fileInput.click();
    },
    handleFileChange(event) {
      const file = event.target.files[0];

      if (file) {
        this.images = file
        // Use FileReader to read the selected image
        const reader = new FileReader();
        reader.onload = (e) => {
          this.selectedImage = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    },


    save(){
    //             const formData = new FormData();
    // formData.append('image', this.images); 
    // formData.append('bio', this.form.bio);
    // formData.append('facebook', this.form.facebook);
    // formData.append('instagram', this.form.instagram);
    // formData.append('linkdin', this.form.linkdin);
    // formData.append('username', this.form.user_name);


                byMethod(this.method, '/api/package' , this.form)
                     .then((res) => {
                       
                         if(res.data.saved) {
                            this.$emit('cancel');
                            // this.$router.push('admin/dashborad4')
                          console.log(res.data.saved)
                          
                            // this.$router.push('/brands');
                          
                         }
                     })
                     .catch((error) => {
                         if(error.response.status === 422) {
                             this.errors = error.response.data.errors
                         }
                         this.isProcessing = false
                     })
            },
            setData(res) {
        
              Vue.set(this.$data, 'form', res.data.data)
              console.log(res.data.data)

          },
        }
    }
</script>

<style scoped>
*{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}
.main-div {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top:50px;
}

.main-box {
    width: 67.20%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: column;
    align-content: center;
    align-items: center;
    background-color: #FF9966;
    border-radius: 50px;
    gap: 35px;
    padding: 40px 0px;
}

.logo-from {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.main-form {
    width: 75%;
    border-radius: 40px;
    background: #FFF;
    box-shadow: 0px 4px 35px 0px rgba(0, 0, 0, 0.08);
}

.form-col-1 {
    display: flex;
    width: 100%;
    height: 152px;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
    background-image:url(/images/bgimg.png);
    /* background: linear-gradient(90deg, rgba(255, 153, 102, 0.29) 0%, rgba(255, 153, 102, 0.72) 50.04%, rgba(255, 153, 102, 0.29) 100%), lightgray 0px -359.563px / 141.93% 598.766% no-repeat; */
    border-radius: 40px 40px 0px 0px;
    opacity: 0.7;
}

.form-col-2 {
    width: 100%;
    padding: 33px 95px;
}

.input-box {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
}

.input-group {
    width: 48%;
    display: flex;
    flex-direction: column;
}

.input-group-1 {
    display: flex;
    flex-direction: column;
    justify-content: center;
    width: 100%;
}

.input-group-3 {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.input-group label {
    color: #000;
    font-family: sans-serif;
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    padding-bottom: 15px;
}

.input-3 {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.input-3 label {
    color: #000;
    font-family: sans-serif;
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    width: 100%;
    padding-bottom: 10px;
}

.input-3 input {
    width: 24%;
    border-radius: 9px;
    border: 1px solid #ADADAD;
    padding: 10px 10px 10px 40px;
}




.icon-input1 {
    /* background-image: url("/images/mdi_graph-line.pn"); */
    background-image: url(/images/mdi_graph-line.png);
    background-repeat: no-repeat;
    background-position: 10px center;
    padding-left: 40px; /* Adjust this value based on the width of your SVG icon */
  }
  .icon-input2 {
    background-image: url(/images/mdi_graph-line.png);
    /* background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M13.028 2C14.153 2.003 14.724 2.009 15.217 2.023L15.411 2.03C15.635 2.038 15.856 2.048 16.123 2.06C17.187 2.11 17.913 2.278 18.55 2.525C19.21 2.779 19.766 3.123 20.322 3.678C20.8305 4.1779 21.2239 4.78259 21.475 5.45C21.722 6.087 21.89 6.813 21.94 7.878C21.952 8.144 21.962 8.365 21.97 8.59L21.976 8.784C21.991 9.276 21.997 9.847 21.999 10.972L22 11.718V13.028C22.0024 13.7574 21.9948 14.4868 21.977 15.216L21.971 15.41C21.963 15.635 21.953 15.856 21.941 16.122C21.891 17.187 21.721 17.912 21.475 18.55C21.2246 19.2178 20.8311 19.8226 20.322 20.322C19.8219 20.8303 19.2173 21.2238 18.55 21.475C17.913 21.722 17.187 21.89 16.123 21.94C15.8857 21.9512 15.6483 21.9612 15.411 21.97L15.217 21.976C14.724 21.99 14.153 21.997 13.028 21.999L12.282 22H10.973C10.2432 22.0025 9.51349 21.9949 8.78397 21.977L8.58997 21.971C8.35258 21.962 8.11524 21.9517 7.87797 21.94C6.81397 21.89 6.08797 21.722 5.44997 21.475C4.78264 21.2244 4.17818 20.8308 3.67897 20.322C3.17001 19.8223 2.77619 19.2176 2.52497 18.55C2.27797 17.913 2.10997 17.187 2.05997 16.122C2.04883 15.8847 2.03883 15.6474 2.02997 15.41L2.02497 15.216C2.00654 14.4868 1.9982 13.7574 1.99997 13.028V10.972C1.99718 10.2426 2.00451 9.5132 2.02197 8.784L2.02897 8.59C2.03697 8.365 2.04697 8.144 2.05897 7.878C2.10897 6.813 2.27697 6.088 2.52397 5.45C2.77508 4.7819 3.16969 4.17702 3.67997 3.678C4.17906 3.16947 4.78311 2.77599 5.44997 2.525C6.08797 2.278 6.81297 2.11 7.87797 2.06C8.14397 2.048 8.36597 2.038 8.58997 2.03L8.78397 2.024C9.51316 2.00623 10.2426 1.99857 10.972 2.001L13.028 2ZM12 7C10.6739 7 9.40211 7.52678 8.46443 8.46447C7.52675 9.40215 6.99997 10.6739 6.99997 12C6.99997 13.3261 7.52675 14.5979 8.46443 15.5355C9.40211 16.4732 10.6739 17 12 17C13.326 17 14.5978 16.4732 15.5355 15.5355C16.4732 14.5979 17 13.3261 17 12C17 10.6739 16.4732 9.40215 15.5355 8.46447C14.5978 7.52678 13.326 7 12 7ZM12 9C12.3939 8.99993 12.7841 9.07747 13.1481 9.22817C13.5121 9.37887 13.8428 9.5998 14.1214 9.87833C14.4001 10.1569 14.6211 10.4875 14.7719 10.8515C14.9227 11.2154 15.0004 11.6055 15.0005 11.9995C15.0005 12.3935 14.923 12.7836 14.7723 13.1476C14.6216 13.5116 14.4007 13.8423 14.1221 14.121C13.8436 14.3996 13.5129 14.6206 13.149 14.7714C12.785 14.9223 12.3949 14.9999 12.001 15C11.2053 15 10.4423 14.6839 9.87965 14.1213C9.31704 13.5587 9.00097 12.7956 9.00097 12C9.00097 11.2044 9.31704 10.4413 9.87965 9.87868C10.4423 9.31607 11.2053 9 12.001 9M17.251 5.5C16.9194 5.5 16.6015 5.6317 16.3671 5.86612C16.1327 6.10054 16.001 6.41848 16.001 6.75C16.001 7.08152 16.1327 7.39946 16.3671 7.63388C16.6015 7.8683 16.9194 8 17.251 8C17.5825 8 17.9004 7.8683 18.1349 7.63388C18.3693 7.39946 18.501 7.08152 18.501 6.75C18.501 6.41848 18.3693 6.10054 18.1349 5.86612C17.9004 5.6317 17.5825 5.5 17.251 5.5Z' fill='%23FF5757'/%3E%3C/svg%3E"); */
    background-repeat: no-repeat;
    background-position: 10px center;
    padding-left: 40px;
}

  .icon-input3 {
    background-image: url(/images/mdi_graph-line.png);
    /* background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M19 3C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19ZM18.5 18.5V13.2C18.5 12.3354 18.1565 11.5062 17.5452 10.8948C16.9338 10.2835 16.1046 9.94 15.24 9.94C14.39 9.94 13.4 10.46 12.92 11.24V10.13H10.13V18.5H12.92V13.57C12.92 12.8 13.54 12.17 14.31 12.17C14.6813 12.17 15.0374 12.3175 15.2999 12.5801C15.5625 12.8426 15.71 13.1987 15.71 13.57V18.5H18.5ZM6.88 8.56C7.32556 8.56 7.75288 8.383 8.06794 8.06794C8.383 7.75288 8.56 7.32556 8.56 6.88C8.56 5.95 7.81 5.19 6.88 5.19C6.43178 5.19 6.00193 5.36805 5.68499 5.68499C5.36805 6.00193 5.19 6.43178 5.19 6.88C5.19 7.81 5.95 8.56 6.88 8.56ZM8.27 18.5V10.13H5.5V18.5H8.27Z' fill='%23FF5757'/%3E%3C/svg%3E"); */
    background-repeat: no-repeat;
    background-position: 10px center;
    padding-left: 40px; /* Adjust this value based on the width of your SVG icon */
  }

  .icon-input4 {
    background-image: url(/images/mdi_graph-line.png);
    /* background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none'%3E%3Cpath d='M19 3C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19ZM18.5 18.5V13.2C18.5 12.3354 18.1565 11.5062 17.5452 10.8948C16.9338 10.2835 16.1046 9.94 15.24 9.94C14.39 9.94 13.4 10.46 12.92 11.24V10.13H10.13V18.5H12.92V13.57C12.92 12.8 13.54 12.17 14.31 12.17C14.6813 12.17 15.0374 12.3175 15.2999 12.5801C15.5625 12.8426 15.71 13.1987 15.71 13.57V18.5H18.5ZM6.88 8.56C7.32556 8.56 7.75288 8.383 8.06794 8.06794C8.383 7.75288 8.56 7.32556 8.56 6.88C8.56 5.95 7.81 5.19 6.88 5.19C6.43178 5.19 6.00193 5.36805 5.68499 5.68499C5.36805 6.00193 5.19 6.43178 5.19 6.88C5.19 7.81 5.95 8.56 6.88 8.56ZM8.27 18.5V10.13H5.5V18.5H8.27Z' fill='%23FF5757'/%3E%3C/svg%3E"); */
    background-repeat: no-repeat;
    background-position: 10px center;
    padding-left: 40px; /* Adjust this value based on the width of your SVG icon */
  }

.input-group-1 lable {}

.input-group-1 label {color: #000;font-family: sans-serif;font-size: 16px;font-style: normal;font-weight: 400;line-height: normal;padding-bottom: 15px;}

.input-group-3 label {
    width: 100%;
    color: #000;
    font-family: sans-serif;
    font-size: 16px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    padding-bottom: 15px;
}

.input-group input {
    border-radius: 9px;
    border: 1px solid #ADADAD;
    background: #FFF;
    padding: 15px;
    flex-shrink: 0;
    width: 100%;
}

.input-group select {
    border-radius: 9px;
    border: 1px solid #ADADAD;
    background: #FFF;
    padding: 15px;
    flex-shrink: 0;
    width: 100%;
}

.input-group-1 input {
    border-radius: 9px;
    border: 1px solid #ADADAD;
    background: #FFF;
    padding: 15px;
    width: 100%;
}


.input-group-1 textarea {
    border-radius: 9px;
    border: 1px solid #ADADAD;
    background: #FFF;
    padding: 15px;
    width: 100%;
}

.input-group-3 input {
    border-radius: 9px;
    border: 1px solid #ADADAD;
    background: #FFF;
    padding: 15px;
    width: 30%;
}

.imagestate{
    width: 13%;
    position: relative;
    z-index: 1;
   
    margin-top: -70px;
    border-radius: 50%;
    max-height: 125px;
    -o-object-fit: cover;
    object-fit: cover;
    left: 50px;
    opacity: 0.8;
    min-height: 115px;
}
.imagestate::before {
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: rgba(255, 0, 0, 0.5); 
    border-radius: 50%;
}

.buttons {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;
    padding-top: 10px;
}

.Hire {
    border-radius: 6px;
    border: 1px solid #000;
    background: #F96;
    box-shadow: 2px 2px 0px 0px #1B1C1D;
    color: #fff;
}

button.Hire {
    display: flex;
    width: 154.75px;
    height: 44px;
    padding: 10px 18px;
    justify-content: center;
    align-items: center;
    gap: 7.647px;
    flex-shrink: 0;
}


.custom-file-input {
  position: relative;
  display: inline-block;
  cursor: pointer;
}

.custom-file-input input {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
}


@media screen and (max-width: 1440px){

    .main-div {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top:0px;
}

    .main-box {
    width: 80%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    flex-direction: column;
    align-content: center;
    align-items: center;
    background-color: #FF9966;
    border-radius: 50px;
    gap: 35px;
    padding: 20px 0px;
}


.imagestate{
    width: 14%;
    position: relative;
    z-index: 1;
    
    margin-top: -70px;
    border-radius: 50%;
    max-height: 115px;
    min-height: 115px;
    -o-object-fit: cover;
    object-fit: cover;
    left: 50px;

    opacity: 0.8;
}
}

</style>