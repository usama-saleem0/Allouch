<template>
    <ul
      class="navbar-nav sidebar "
     
    >
    </ul>
    <!-- End of Sidebar -->
</template>

<script>

export default {
    name: 'Sidebar'
}
</script>
