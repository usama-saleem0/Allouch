<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayPal Transaction</title>
</head>
<body>
    <h1>PayPal Transaction</h1>

    <?php if(session('success')): ?>
        <div style="color: green;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div style="color: red;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('processTransaction')); ?>" method="get">
        <?php echo csrf_field(); ?>
        <button type="submit">Pay Now</button>
    </form>
</body>
</html>
<?php /**PATH D:\laragon\www\Allouch\resources\views/transaction.blade.php ENDPATH**/ ?>